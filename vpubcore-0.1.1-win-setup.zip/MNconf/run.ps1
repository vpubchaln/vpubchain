$args="C:\Program Files\vpubcore" 
#����path��vpubd,vpub-cliִ��·��
$Env:path=$Env:Path+";"+$args+"\daemon" 
echo $Env:path
vpub-cli masternode start-alias MN
#$uuid=(get-wmiobject Win32_ComputerSystemProduct).UUID
#vpu-cli masternode start-alias $uuid