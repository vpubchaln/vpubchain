$config_path="C:\Users\"+$env:USERNAME+"\AppData\Roaming\VpubCore\"
echo $config_path
$server="server=1" 
$PSDefaultParameterValues['Out-File:Encoding'] = 'default'
echo $server >$config_path"vpub.conf"


