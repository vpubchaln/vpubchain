﻿<#
    author 陆
    date   2019-01-11
#>
<#
#获取powershell的版本号
echo $PSVersionTable
#获取当前目录
$current_path=echo "$PWD" 
$Env:path=$Env:Path+";"+$current_path+"\daemon"
echo $Env:path
#>

$PSDefaultParameterValues['Out-File:Encoding'] = 'default'

function ConvertFrom-Json([String]$sRawJson) {
    [System.Reflection.Assembly]::LoadWithPartialName("System.Web.Extensions") `
        | Out-Null
    $oJsSerializer = `
        New-Object System.Web.Script.Serialization.JavaScriptSerializer

    return $oJsSerializer.DeserializeObject($sRawJson)
}

#担保金额
$collateral=1000	

#程序安装默认目录
$args="C:\Program Files\VpubCore" 

#app数据目录
$config_path="C:\Users\"+$env:USERNAME+"\AppData\Roaming\VpubCore\"	
echo $config_path

#设置path的vpubd,vpub-cli执行路径
$Env:path=$Env:Path+";"+$args+"\daemon" 
echo $Env:path

REG DELETE HKEY_CURRENT_USER\Software\Vpub\Vpub-Qt /f
REG IMPORT vpub.reg

#获取外部ip
$externalip=(Invoke-WebRequest 'www.icanhazip.com' -UseBasicParsing).Content.trim()
echo $externalip
#获取私钥
$masterprivkey=vpub-cli masternode genkey
#获取钱包地址
$address=vpub-cli getnewaddress
#获取钱包余额
$balance=vpub-cli getbalance
if ($balance -lt $collateral)
{
    echo "账户余额不足"
    return -1
}
#获取钱交易ID
$txid=vpub-cli sendtoaddress "$address" $collateral
#获取钱交易ID
$JSON=vpub-cli masternode outputs

#解析json，找到对应txid的txindex
$jsonObj = ConvertFrom-Json($JSON)
if ($jsonObj.Count -eq 0)
{
   echo "没有主节点输出"
   return -2
}

$i=0
foreach ($n in $jsonObj.Keys)
{
    $i=$i+1
    if ($n -eq $txid)
    {    
        break
    }

}
$j=0
foreach ($n in $jsonObj.Values)
{
    $j=$j+1
    if ($j -eq $i)
    {
        $txindex=$n
        break
    }

}


#write to masternode.conf
$masternode_content ="MN"+" "+ $externalip+":9900"+ " " + $masterprivkey + " " + $txid.Replace('"',"") + " " + " " + $txindex.Replace('"',"")
echo $masternode_content > $config_path"masternode.conf"


$listen="listen=1"
$sever ="server=1"
$daemon="daemon=1"
$maxconnections="maxconnections=64"
$masternode="masternode=1"
$externalip_lable="externalip="+$externalip
$masternodeprivkey_lable="masternodeprivkey="+$masterprivkey
$test =$listen+"`r`n"+$sever+"`r`n"+$daemon+"`r`n"+$maxconnections+"`r`n"+$masternode+"`r`n"+$masternodeprivkey_lable+"`r`n"+$externalip_lable+"`r`n"

#write to vpub.conf
echo $test >$config_path"vpub.conf"


<#

$result=Test-Path test.ps1
if ( $result == "true" )
	echo $result
else
	echo "no exist"
#>

<#


$sBlockcContent  = '
{
    "name": "BlockC",
    "value": "Value_C"
}
'

$jsonBlockcObj = ConvertFrom-Json($sBlockcContent)

foreach ($n in $jsonBlockcObj.Keys)
{
    $a=$n
    break
}
foreach ($n in $jsonBlockcObj.Values)
{
    $b=$n
    break
}
$a="aaaaaaaaaaaaaaaa:"+$a
$b="bbbbbbbbbbbbbbbb:"+$b
echo $a
echo $b
#>